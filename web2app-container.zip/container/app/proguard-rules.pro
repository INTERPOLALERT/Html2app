# The JavaScript bridge is reached by name from web content, so it must survive
# any future shrinking. Release builds do not minify today, but this keeps the
# contract explicit if that ever changes.
-keepclassmembers class com.web2app.container.NativeBridge {
    public *;
}
-keepattributes JavascriptInterface
