package com.web2app.container;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Turns a file the user picked into an installed app directory.
 *
 * Accepts a single .html page or a .zip holding a whole site. Everything is
 * copied into the app's own private storage, so the source file can be deleted
 * afterwards without breaking anything.
 */
public final class Importer {

    /** Refuse anything that would take an unreasonable amount of storage. */
    private static final long MAX_TOTAL = 256L * 1024 * 1024;
    private static final int MAX_ENTRIES = 4000;

    private static final Pattern TITLE =
            Pattern.compile("<title[^>]*>([\\s\\S]{0,200}?)</title>", Pattern.CASE_INSENSITIVE);
    private static final Pattern THEME_COLOR = Pattern.compile(
            "<meta[^>]*name\\s*=\\s*[\"']theme-color[\"'][^>]*content\\s*=\\s*[\"'](#[0-9a-fA-F]{6})[\"']",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern THEME_COLOR_ALT = Pattern.compile(
            "<meta[^>]*content\\s*=\\s*[\"'](#[0-9a-fA-F]{6})[\"'][^>]*name\\s*=\\s*[\"']theme-color[\"']",
            Pattern.CASE_INSENSITIVE);

    private Importer() { }

    public static class ImportException extends Exception {
        ImportException(String msg) { super(msg); }
        ImportException(String msg, Throwable t) { super(msg, t); }
    }

    public static AppStore.Entry importFrom(Context ctx, Uri uri) throws ImportException {
        String displayName = queryName(ctx, uri);
        String id = AppStore.newId();
        File dir = AppStore.dirFor(ctx, id);
        if (!dir.mkdirs()) {
            throw new ImportException("Could not create storage for the app.");
        }

        try {
            byte[] head = new byte[4];
            int headLen;
            try (InputStream probe = open(ctx, uri)) {
                headLen = readFully(probe, head, 4);
            }
            boolean looksZip = headLen == 4
                    && head[0] == 0x50 && head[1] == 0x4B
                    && (head[2] == 0x03 || head[2] == 0x05 || head[2] == 0x07);

            if (looksZip) {
                try (InputStream in = open(ctx, uri)) {
                    unzipInto(in, dir);
                }
                stripCommonRoot(dir);
            } else {
                try (InputStream in = open(ctx, uri)) {
                    writeStream(in, new File(dir, "index.html"), MAX_TOTAL);
                }
            }

            String entry = findEntry(dir);
            if (entry == null) {
                throw new ImportException("No .html file found. An app needs at least one page.");
            }

            String html = "";
            try {
                byte[] raw = AppStore.readAll(new File(dir, entry));
                html = new String(raw, StandardCharsets.UTF_8);
            } catch (IOException ignored) {
                // Unreadable entry page is still importable; it just gets a
                // default name and colour.
            }

            AppStore.Entry e = new AppStore.Entry();
            e.id = id;
            e.entry = entry;
            e.name = pickName(html, displayName);
            e.color = pickColor(html);
            e.created = System.currentTimeMillis();
            e.bytes = AppStore.sizeOf(dir);
            return e;

        } catch (ImportException ex) {
            AppStore.deleteTree(dir);
            throw ex;
        } catch (IOException ex) {
            AppStore.deleteTree(dir);
            throw new ImportException("Could not read that file: " + ex.getMessage(), ex);
        } catch (RuntimeException ex) {
            AppStore.deleteTree(dir);
            throw new ImportException("That file could not be imported.", ex);
        }
    }

    private static InputStream open(Context ctx, Uri uri) throws IOException {
        ContentResolver cr = ctx.getContentResolver();
        InputStream in = cr.openInputStream(uri);
        if (in == null) throw new IOException("the file could not be opened");
        return new BufferedInputStream(in, 32 * 1024);
    }

    private static int readFully(InputStream in, byte[] buf, int len) throws IOException {
        int off = 0;
        while (off < len) {
            int n = in.read(buf, off, len - off);
            if (n < 0) break;
            off += n;
        }
        return off;
    }

    private static String queryName(Context ctx, Uri uri) {
        String name = null;
        try (Cursor c = ctx.getContentResolver()
                .query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (RuntimeException ignored) {
            // Some providers do not answer this query. A default name is fine.
        }
        if (name == null) return "My App";
        return name.replaceAll("\\.(html?|zip)$", "").replace('_', ' ').replace('-', ' ').trim();
    }

    /**
     * Extracts a zip, rejecting any entry whose resolved path escapes the target
     * directory. That check is the difference between a file importer and a
     * remote-code-execution bug.
     */
    private static void unzipInto(InputStream in, File dir) throws IOException, ImportException {
        String root = dir.getCanonicalPath() + File.separator;
        long total = 0;
        int count = 0;

        try (ZipInputStream zin = new ZipInputStream(in)) {
            ZipEntry ze;
            while ((ze = zin.getNextEntry()) != null) {
                String name = ze.getName();
                if (name == null || name.isEmpty()) continue;
                if (name.startsWith("__MACOSX/") || name.endsWith("/.DS_Store")) continue;

                File out = new File(dir, name);
                if (!out.getCanonicalPath().startsWith(root)) {
                    throw new ImportException("That zip contains a file path that points outside the app folder, so it was rejected.");
                }
                if (ze.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                if (++count > MAX_ENTRIES) {
                    throw new ImportException("That zip has more than " + MAX_ENTRIES + " files in it.");
                }
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                total += writeStream(zin, out, MAX_TOTAL - total);
            }
        }
        if (count == 0) throw new ImportException("That zip is empty.");
    }

    private static long writeStream(InputStream in, File out, long limit) throws IOException, ImportException {
        byte[] buf = new byte[32 * 1024];
        long written = 0;
        try (FileOutputStream fos = new FileOutputStream(out)) {
            int n;
            while ((n = in.read(buf)) > 0) {
                written += n;
                if (written > limit) {
                    throw new ImportException("That app is larger than 256 MB.");
                }
                fos.write(buf, 0, n);
            }
        }
        return written;
    }

    /** Zips normally wrap everything in one folder. Flatten it. */
    private static void stripCommonRoot(File dir) {
        File[] kids = dir.listFiles();
        if (kids == null || kids.length != 1 || !kids[0].isDirectory()) return;
        File inner = kids[0];
        File[] moving = inner.listFiles();
        if (moving == null) return;
        for (File m : moving) {
            File target = new File(dir, m.getName());
            if (!m.renameTo(target)) return;   // partial move is worse than none
        }
        inner.delete();
    }

    /** index.html wins; otherwise the shallowest .html file. */
    private static String findEntry(File dir) {
        List<String> html = new ArrayList<>();
        collect(dir, "", html);
        if (html.isEmpty()) return null;
        String best = null;
        int bestDepth = Integer.MAX_VALUE;
        for (String p : html) {
            String lower = p.toLowerCase(Locale.US);
            if (lower.equals("index.html") || lower.equals("index.htm")) return p;
            int depth = p.split("/").length;
            if (depth < bestDepth || (depth == bestDepth && best != null && p.length() < best.length())) {
                best = p;
                bestDepth = depth;
            }
        }
        return best;
    }

    private static void collect(File dir, String prefix, List<String> out) {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            String rel = prefix.isEmpty() ? k.getName() : prefix + "/" + k.getName();
            if (k.isDirectory()) {
                collect(k, rel, out);
            } else if (rel.toLowerCase(Locale.US).matches(".*\\.html?$")) {
                out.add(rel);
            }
        }
    }

    private static String pickName(String html, String fallback) {
        Matcher m = TITLE.matcher(html);
        if (m.find()) {
            String t = m.group(1).replaceAll("\\s+", " ").trim();
            if (!t.isEmpty()) return t.length() > 40 ? t.substring(0, 40) : t;
        }
        if (fallback == null || fallback.trim().isEmpty()) return "My App";
        return fallback.length() > 40 ? fallback.substring(0, 40) : fallback;
    }

    private static String pickColor(String html) {
        Matcher m = THEME_COLOR.matcher(html);
        if (m.find()) return m.group(1).toUpperCase(Locale.US);
        m = THEME_COLOR_ALT.matcher(html);
        if (m.find()) return m.group(1).toUpperCase(Locale.US);
        return "#2B4CE0";
    }
}
