package com.web2app.container;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import java.io.File;
import java.util.Locale;

/**
 * Gives every imported app a home-screen icon.
 *
 * If the app shipped one, that gets used. If not, we draw initials on the app's
 * own theme colour, which is a lot better than every icon looking identical.
 */
public final class IconFactory {

    /** Files an HTML app is likely to have called its icon. */
    private static final String[] CANDIDATES = {
            "icons/icon-512.png",
            "icons/icon-192.png",
            "icons/icon-maskable-512.png",
            "icon-512.png",
            "icon-192.png",
            "icon.png",
            "apple-touch-icon.png",
            "favicon.png",
            "assets/icon.png",
            "img/icon.png",
            "images/icon.png"
    };

    private IconFactory() { }

    public static Bitmap forApp(Context ctx, AppStore.Entry e, int size) {
        Bitmap shipped = loadShipped(AppStore.dirFor(ctx, e.id), size);
        if (shipped != null) return padForAdaptive(shipped, size, parse(e.color));
        return drawInitials(e.name, parse(e.color), size);
    }

    private static Bitmap loadShipped(File dir, int size) {
        for (String rel : CANDIDATES) {
            File f = new File(dir, rel);
            if (!f.isFile() || f.length() == 0 || f.length() > 8L * 1024 * 1024) continue;
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(f.getAbsolutePath(), bounds);
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) continue;

                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = Math.max(1, Math.min(bounds.outWidth, bounds.outHeight) / size);
                Bitmap bmp = BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
                if (bmp != null) return bmp;
            } catch (OutOfMemoryError | RuntimeException ignored) {
                // Try the next candidate rather than failing the whole import.
            }
        }
        return null;
    }

    /**
     * Android crops adaptive icons into a circle or squircle and eats about 20%
     * of the edges, so artwork is scaled into the middle and the gap is filled
     * with the app's colour.
     */
    private static Bitmap padForAdaptive(Bitmap src, int size, int bg) {
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(bg);

        float safe = size * 0.70f;
        float scale = Math.min(safe / src.getWidth(), safe / src.getHeight());
        float w = src.getWidth() * scale;
        float h = src.getHeight() * scale;
        float left = (size - w) / 2f;
        float top = (size - h) / 2f;

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setFilterBitmap(true);
        c.drawBitmap(src,
                new Rect(0, 0, src.getWidth(), src.getHeight()),
                new Rect((int) left, (int) top, (int) (left + w), (int) (top + h)),
                p);
        if (src != out) src.recycle();
        return out;
    }

    private static Bitmap drawInitials(String name, int bg, int size) {
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(bg);

        String glyph = initials(name);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(onColor(bg));
        p.setTextAlign(Paint.Align.CENTER);
        p.setFakeBoldText(true);
        p.setTextSize(size * (glyph.length() > 1 ? 0.30f : 0.36f));

        Paint.FontMetrics fm = p.getFontMetrics();
        float baseline = size / 2f - (fm.ascent + fm.descent) / 2f;
        c.drawText(glyph, size / 2f, baseline, p);
        return out;
    }

    private static String initials(String name) {
        if (name == null) return "A";
        String trimmed = name.trim();
        if (trimmed.isEmpty()) return "A";
        String[] words = trimmed.split("\\s+");
        if (words.length >= 2 && !words[0].isEmpty() && !words[1].isEmpty()) {
            return ("" + words[0].charAt(0) + words[1].charAt(0)).toUpperCase(Locale.US);
        }
        return trimmed.substring(0, Math.min(2, trimmed.length())).toUpperCase(Locale.US);
    }

    public static int parse(String hex) {
        try {
            return Color.parseColor(hex);
        } catch (IllegalArgumentException | NullPointerException e) {
            return 0xFF2B4CE0;
        }
    }

    /** Black on light colours, white on dark ones, using relative luminance. */
    public static int onColor(int bg) {
        double r = lin(Color.red(bg) / 255.0);
        double g = lin(Color.green(bg) / 255.0);
        double b = lin(Color.blue(bg) / 255.0);
        double l = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return l > 0.45 ? 0xFF101010 : 0xFFFFFFFF;
    }

    private static double lin(double c) {
        return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    }

    /** Slightly darkened, for the status bar behind a light theme colour. */
    public static int darken(int c) {
        return Color.rgb(
                (int) (Color.red(c) * 0.82f),
                (int) (Color.green(c) * 0.82f),
                (int) (Color.blue(c) * 0.82f));
    }
}
