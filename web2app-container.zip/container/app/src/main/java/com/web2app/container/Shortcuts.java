package com.web2app.container;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;

import androidx.core.content.pm.ShortcutInfoCompat;
import androidx.core.content.pm.ShortcutManagerCompat;
import androidx.core.graphics.drawable.IconCompat;

/**
 * Puts an imported app on the home screen as its own icon.
 *
 * The launcher treats this exactly like any app icon: custom name, custom
 * artwork, one tap straight into the app with no container UI in between.
 */
public final class Shortcuts {

    private Shortcuts() { }

    public static Intent launchIntent(Context ctx, AppStore.Entry e) {
        Intent i = new Intent(ctx, AppActivity.class);
        i.setAction(Intent.ACTION_VIEW);
        // Unique data per app so the launcher and the recents switcher keep them
        // apart instead of folding them into one task.
        i.setData(Uri.parse("web2app://app/" + e.id));
        i.putExtra(AppActivity.EXTRA_APP_ID, e.id);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
        return i;
    }

    public static boolean supported(Context ctx) {
        return ShortcutManagerCompat.isRequestPinShortcutSupported(ctx);
    }

    /**
     * Asks the launcher to pin the icon. Android shows its own confirmation
     * dialog; there is no way to place an icon without the user agreeing.
     */
    public static boolean pin(Context ctx, AppStore.Entry e) {
        if (!supported(ctx)) return false;

        Bitmap bmp = IconFactory.forApp(ctx, e, 192);
        ShortcutInfoCompat info = new ShortcutInfoCompat.Builder(ctx, "app_" + e.id)
                .setShortLabel(shortLabel(e.name))
                .setLongLabel(e.name)
                .setIcon(IconCompat.createWithAdaptiveBitmap(bmp))
                .setIntent(launchIntent(ctx, e))
                .build();

        return ShortcutManagerCompat.requestPinShortcut(ctx, info, null);
    }

    /** Keeps the icon caption from being truncated to nonsense. */
    private static String shortLabel(String name) {
        if (name == null || name.trim().isEmpty()) return "App";
        String t = name.trim();
        return t.length() > 12 ? t.substring(0, 12).trim() : t;
    }
}
