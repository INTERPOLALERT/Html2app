package com.web2app.container;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The list of imported apps and where their files live.
 *
 * Each app owns a directory under filesDir/apps/&lt;id&gt; and is served to the
 * WebView from https://&lt;id&gt;.web2app.local/. Because every app gets a
 * different host, the browser engine treats them as different origins, so their
 * localStorage, IndexedDB, cookies and caches never collide.
 */
public final class AppStore {

    public static final String HOST_SUFFIX = ".web2app.local";
    private static final String INDEX_FILE = "apps.json";

    private AppStore() { }

    public static final class Entry {
        public String id;
        public String name;
        public String entry;      // relative path of the page that starts the app
        public String color;      // #RRGGBB used for the icon and status bar
        public long created;
        public long bytes;

        public String host() {
            return id + HOST_SUFFIX;
        }

        public String startUrl() {
            return "https://" + host() + "/" + entry;
        }
    }

    public static File appsRoot(Context c) {
        File f = new File(c.getFilesDir(), "apps");
        if (!f.exists() && !f.mkdirs()) {
            // Nothing sensible to do here; callers surface the failure when
            // they try to write into the directory.
        }
        return f;
    }

    public static File dirFor(Context c, String id) {
        return new File(appsRoot(c), id);
    }

    /** Lowercase hex, so it is always a legal DNS label for the asset host. */
    public static String newId() {
        byte[] b = new byte[6];
        new SecureRandom().nextBytes(b);
        StringBuilder sb = new StringBuilder("a");
        for (byte x : b) sb.append(String.format(Locale.US, "%02x", x));
        return sb.toString();
    }

    public static synchronized List<Entry> load(Context c) {
        List<Entry> out = new ArrayList<>();
        File f = new File(c.getFilesDir(), INDEX_FILE);
        if (!f.exists()) return out;
        try {
            byte[] raw = readAll(f);
            JSONArray arr = new JSONArray(new String(raw, StandardCharsets.UTF_8));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Entry e = new Entry();
                e.id = o.getString("id");
                e.name = o.optString("name", "App");
                e.entry = o.optString("entry", "index.html");
                e.color = o.optString("color", "#2B4CE0");
                e.created = o.optLong("created", 0L);
                e.bytes = o.optLong("bytes", 0L);
                if (dirFor(c, e.id).isDirectory()) out.add(e);
            }
        } catch (JSONException | IOException ex) {
            // A corrupt index should not brick the app. Worst case the user
            // re-imports; the files themselves are still on disk.
        }
        return out;
    }

    public static synchronized void save(Context c, List<Entry> list) throws IOException {
        JSONArray arr = new JSONArray();
        try {
            for (Entry e : list) {
                JSONObject o = new JSONObject();
                o.put("id", e.id);
                o.put("name", e.name);
                o.put("entry", e.entry);
                o.put("color", e.color);
                o.put("created", e.created);
                o.put("bytes", e.bytes);
                arr.put(o);
            }
        } catch (JSONException ex) {
            throw new IOException("Could not write the app list", ex);
        }
        File f = new File(c.getFilesDir(), INDEX_FILE);
        File tmp = new File(c.getFilesDir(), INDEX_FILE + ".tmp");
        try (FileOutputStream fos = new FileOutputStream(tmp)) {
            fos.write(arr.toString().getBytes(StandardCharsets.UTF_8));
            fos.getFD().sync();
        }
        if (!tmp.renameTo(f)) {
            throw new IOException("Could not save the app list");
        }
    }

    public static synchronized void add(Context c, Entry e) throws IOException {
        List<Entry> all = load(c);
        all.add(0, e);
        save(c, all);
    }

    public static synchronized void update(Context c, Entry changed) throws IOException {
        List<Entry> all = load(c);
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(changed.id)) {
                all.set(i, changed);
                break;
            }
        }
        save(c, all);
    }

    public static Entry find(Context c, String id) {
        if (id == null) return null;
        for (Entry e : load(c)) {
            if (e.id.equals(id)) return e;
        }
        return null;
    }

    /** Used by the service-worker interceptor, which only sees a host name. */
    public static Entry findByHost(Context c, String host) {
        if (host == null || !host.endsWith(HOST_SUFFIX)) return null;
        return find(c, host.substring(0, host.length() - HOST_SUFFIX.length()));
    }

    public static synchronized void delete(Context c, String id) throws IOException {
        List<Entry> all = load(c);
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(id)) {
                all.remove(i);
                break;
            }
        }
        save(c, all);
        deleteTree(dirFor(c, id));
    }

    public static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) deleteTree(k);
        }
        // Ignore the result: a file we cannot remove is reported by the caller
        // noticing the directory still exists, which is not worth an exception.
        f.delete();
    }

    public static long sizeOf(File f) {
        if (f == null || !f.exists()) return 0L;
        if (f.isFile()) return f.length();
        long total = 0L;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) total += sizeOf(k);
        }
        return total;
    }

    public static byte[] readAll(File f) throws IOException {
        long len = f.length();
        if (len > 64L * 1024 * 1024) throw new IOException("File is too large to read");
        byte[] buf = new byte[(int) len];
        try (FileInputStream in = new FileInputStream(f)) {
            int off = 0;
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n < 0) break;
                off += n;
            }
        }
        return buf;
    }
}
