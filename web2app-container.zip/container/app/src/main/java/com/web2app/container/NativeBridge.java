package com.web2app.container;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * The capabilities a browser tab does not get.
 *
 * Standard web APIs still work exactly as written — getUserMedia, geolocation,
 * IndexedDB, notifications and the rest are all live, because every app is
 * served over https from its own origin. This bridge only adds the things the
 * web platform genuinely cannot do on Android.
 *
 * Every method here runs on the WebView's JavaBridge thread, never the UI
 * thread, so anything that touches the screen is posted through the host.
 */
public final class NativeBridge {

    /** Implemented by AppActivity. Keeps this class free of Activity lifecycle. */
    public interface Host {
        void runOnUi(Runnable r);
        void resolve(int requestId, String json);
        void requestFilePick(int requestId, String mimeType);
        void requestNotification(int requestId, String title, String body);
        void setStatusBarColor(int color);
        void setKeepAwake(boolean on);
        void shareText(String text, String title);
        void toast(String message);
        void vibrate(long ms);
        void closeApp();
    }

    private final Context ctx;
    private final Host host;
    private final AppStore.Entry app;
    private final AtomicInteger requestIds = new AtomicInteger(1);

    public NativeBridge(Context ctx, Host host, AppStore.Entry app) {
        this.ctx = ctx.getApplicationContext();
        this.host = host;
        this.app = app;
    }

    /* ------------------------------------------------------------------ *
     * Instant feedback
     * ------------------------------------------------------------------ */

    @JavascriptInterface
    public void toast(String message) {
        if (message == null) return;
        host.toast(message.length() > 200 ? message.substring(0, 200) : message);
    }

    @JavascriptInterface
    public void vibrate(int milliseconds) {
        host.vibrate(Math.max(1, Math.min(milliseconds, 5000)));
    }

    @JavascriptInterface
    public void keepAwake(boolean on) {
        host.setKeepAwake(on);
    }

    @JavascriptInterface
    public void setStatusBarColor(String hex) {
        host.setStatusBarColor(IconFactory.parse(hex));
    }

    @JavascriptInterface
    public void share(String text, String title) {
        host.shareText(text == null ? "" : text, title);
    }

    @JavascriptInterface
    public void close() {
        host.closeApp();
    }

    /* ------------------------------------------------------------------ *
     * Private storage that outlives the browser cache
     *
     * localStorage and IndexedDB can be wiped by the system under storage
     * pressure. These files live in the app's own directory and only go when
     * the user deletes the app.
     * ------------------------------------------------------------------ */

    @JavascriptInterface
    public boolean writeFile(String name, String text) {
        File f = safeDataFile(name);
        if (f == null || text == null) return false;
        try {
            File parent = f.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) return false;
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(text.getBytes(StandardCharsets.UTF_8));
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    @JavascriptInterface
    public String readFile(String name) {
        File f = safeDataFile(name);
        if (f == null || !f.isFile()) return null;
        try {
            return new String(AppStore.readAll(f), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return null;
        }
    }

    @JavascriptInterface
    public boolean deleteFile(String name) {
        File f = safeDataFile(name);
        return f != null && f.isFile() && f.delete();
    }

    @JavascriptInterface
    public String listFiles() {
        JSONArray arr = new JSONArray();
        File root = dataDir();
        collect(root, "", arr);
        return arr.toString();
    }

    private void collect(File dir, String prefix, JSONArray out) {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            String rel = prefix.isEmpty() ? k.getName() : prefix + "/" + k.getName();
            if (k.isDirectory()) {
                collect(k, rel, out);
            } else {
                try {
                    JSONObject o = new JSONObject();
                    o.put("name", rel);
                    o.put("size", k.length());
                    o.put("modified", k.lastModified());
                    out.put(o);
                } catch (JSONException ignored) {
                    // A single unlistable file should not break the listing.
                }
            }
        }
    }

    private File dataDir() {
        File d = new File(AppStore.dirFor(ctx, app.id), "_data");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** Blocks path traversal and anything that would escape the app's folder. */
    private File safeDataFile(String name) {
        if (name == null || name.isEmpty() || name.length() > 250) return null;
        if (name.contains("..") || name.startsWith("/") || name.contains("\\")) return null;
        File root = dataDir();
        File f = new File(root, name);
        try {
            if (!f.getCanonicalPath().startsWith(root.getCanonicalPath() + File.separator)) return null;
        } catch (IOException e) {
            return null;
        }
        return f;
    }

    /* ------------------------------------------------------------------ *
     * Saving into the phone's real Downloads folder
     * ------------------------------------------------------------------ */

    /**
     * @param name     file name, extension included
     * @param content  plain text, or a data: URL for binary
     * @return the saved location, or null if it failed
     */
    @JavascriptInterface
    public String saveToDownloads(String name, String content) {
        if (name == null || content == null) return null;
        String clean = name.replaceAll("[^A-Za-z0-9._ -]", "_");
        if (clean.isEmpty()) clean = "download";

        byte[] data;
        String mime = "application/octet-stream";
        if (content.startsWith("data:")) {
            int comma = content.indexOf(',');
            if (comma < 0) return null;
            String header = content.substring(5, comma);
            if (header.contains(";")) mime = header.substring(0, header.indexOf(';'));
            else if (!header.isEmpty()) mime = header;
            try {
                data = header.endsWith("base64")
                        ? Base64.decode(content.substring(comma + 1), Base64.DEFAULT)
                        : Uri.decode(content.substring(comma + 1)).getBytes(StandardCharsets.UTF_8);
            } catch (IllegalArgumentException e) {
                return null;
            }
        } else {
            data = content.getBytes(StandardCharsets.UTF_8);
            mime = "text/plain";
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, clean);
                cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                cv.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = ctx.getContentResolver()
                        .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) return null;
                try (OutputStream out = ctx.getContentResolver().openOutputStream(uri)) {
                    if (out == null) return null;
                    out.write(data);
                }
                cv.clear();
                cv.put(MediaStore.Downloads.IS_PENDING, 0);
                ctx.getContentResolver().update(uri, cv, null, null);
                return "Downloads/" + clean;
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) return null;
                File out = new File(dir, clean);
                try (FileOutputStream fos = new FileOutputStream(out)) {
                    fos.write(data);
                }
                return out.getAbsolutePath();
            }
        } catch (IOException | SecurityException | IllegalArgumentException e) {
            return null;
        }
    }

    /* ------------------------------------------------------------------ *
     * Asynchronous calls, resolved back into the promise registry
     * ------------------------------------------------------------------ */

    @JavascriptInterface
    public int pickFile(String mimeType) {
        int id = requestIds.getAndIncrement();
        host.requestFilePick(id, (mimeType == null || mimeType.isEmpty()) ? "*/*" : mimeType);
        return id;
    }

    @JavascriptInterface
    public int notify(String title, String body) {
        int id = requestIds.getAndIncrement();
        host.requestNotification(id, title == null ? app.name : title, body == null ? "" : body);
        return id;
    }

    /* ------------------------------------------------------------------ *
     * Information
     * ------------------------------------------------------------------ */

    @JavascriptInterface
    public String deviceInfo() {
        try {
            JSONObject o = new JSONObject();
            o.put("appName", app.name);
            o.put("appId", app.id);
            o.put("platform", "android");
            o.put("androidVersion", Build.VERSION.RELEASE);
            o.put("sdkInt", Build.VERSION.SDK_INT);
            o.put("model", Build.MODEL);
            o.put("manufacturer", Build.MANUFACTURER);
            o.put("container", "Web2App");
            File root = AppStore.dirFor(ctx, app.id);
            o.put("appBytes", AppStore.sizeOf(root));
            o.put("freeBytes", root.getFreeSpace());
            return o.toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    /* ------------------------------------------------------------------ *
     * The JavaScript half of the bridge.
     *
     * Injected before the page's own scripts run, so window.Native exists by
     * the time app code executes.
     * ------------------------------------------------------------------ */
    /**
     * The JavaScript half of the bridge.
     *
     * Injected before the page's own scripts run, so window.Native exists by the
     * time app code executes. Written as joined lines rather than a text block so
     * it compiles on any toolchain, and kept idempotent so re-injecting is safe.
     */
    public static String shim() {
        return String.join("\n",
            "(function () {",
            "  if (window.Native) return;",
            "  var bridge = window.NativeBridge;",
            "  var pending = {};",
            "",
            "  window.__w2aResolve = function (id, json) {",
            "    var p = pending[id];",
            "    if (!p) return;",
            "    delete pending[id];",
            "    var value = null;",
            "    if (json) { try { value = JSON.parse(json); } catch (e) { value = null; } }",
            "    p(value);",
            "  };",
            "",
            "  function promised(id) {",
            "    return new Promise(function (resolve) {",
            "      if (!id || id < 1) { resolve(null); return; }",
            "      pending[id] = resolve;",
            "    });",
            "  }",
            "",
            "  window.Native = {",
            "    available: true,",
            "    version: 1,",
            "",
            "    toast:     function (m)  { bridge.toast(String(m)); },",
            "    vibrate:   function (ms) { bridge.vibrate(ms | 0); },",
            "    keepAwake: function (on) { bridge.keepAwake(!!on); },",
            "    close:     function ()   { bridge.close(); },",
            "    share:     function (text, title) { bridge.share(String(text), title ? String(title) : null); },",
            "    setStatusBarColor: function (hex) { bridge.setStatusBarColor(String(hex)); },",
            "",
            "    files: {",
            "      write:  function (n, t) { return bridge.writeFile(String(n), String(t)); },",
            "      read:   function (n)    { return bridge.readFile(String(n)); },",
            "      remove: function (n)    { return bridge.deleteFile(String(n)); },",
            "      list:   function ()     { try { return JSON.parse(bridge.listFiles()); } catch (e) { return []; } },",
            "      readJSON: function (n, fallback) {",
            "        var raw = bridge.readFile(String(n));",
            "        if (raw === null || raw === undefined) return fallback;",
            "        try { return JSON.parse(raw); } catch (e) { return fallback; }",
            "      },",
            "      writeJSON: function (n, v) { return bridge.writeFile(String(n), JSON.stringify(v)); }",
            "    },",
            "",
            "    download: function (name, content) { return bridge.saveToDownloads(String(name), String(content)); },",
            "    pickFile: function (mime) { return promised(bridge.pickFile(mime || '*/*')); },",
            "    notify:   function (title, body) { return promised(bridge.notify(title || null, body || '')); },",
            "    info:     function () { try { return JSON.parse(bridge.deviceInfo()); } catch (e) { return {}; } }",
            "  };",
            "",
            "  window.dispatchEvent(new Event('nativeready'));",
            "})();");
    }

    /** Escapes a string so it can be passed into evaluateJavascript safely. */
    public static String jsString(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (ch < 0x20 || ch == 0x2028 || ch == 0x2029) {
                        sb.append(String.format(Locale.US, "\\u%04x", (int) ch));
                    } else {
                        sb.append(ch);
                    }
            }
        }
        return sb.append('"').toString();
    }
}
