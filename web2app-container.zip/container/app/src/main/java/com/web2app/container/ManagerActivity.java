package com.web2app.container;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The container's own screen: import apps, put them on the home screen, remove
 * them. Once an app is pinned the user never has to come back here.
 *
 * The layout is built in code on purpose. It is one screen with one list, and
 * keeping it here means there is exactly one place to look when it changes.
 */
public class ManagerActivity extends AppCompatActivity {

    private static final int INK = 0xFF15171F;
    private static final int INK2 = 0xFF4A4F5E;
    private static final int INK3 = 0xFF767C8C;
    private static final int RULE = 0xFFC6CAD6;
    private static final int CARD = 0xFFF7F8FB;
    private static final int BRAND = 0xFF2B4CE0;
    private static final int BRICK = 0xFFB23A48;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private LinearLayout listHolder;
    private ProgressBar busy;

    private final ActivityResultLauncher<String[]> picker =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) doImport(uri);
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildScreen());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    /* ----------------------------------------------------------- screen -- */

    private View buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout root = column();
        root.setPadding(dp(20), dp(24), dp(20), dp(40));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView eyebrow = text("YOUR APPS", 11, INK3, true);
        eyebrow.setLetterSpacing(0.14f);
        root.addView(eyebrow);

        TextView title = text("Web2App", 30, INK, true);
        title.setLetterSpacing(-0.03f);
        root.addView(title, margins(0, dp(2), 0, dp(4)));

        root.addView(text("Bring in an HTML app and put it on your home screen. "
                + "It runs on this phone, offline, with the camera, microphone, "
                + "storage and notifications a browser tab does not get.", 14, INK2, false),
                margins(0, 0, 0, dp(20)));

        TextView importBtn = filledButton("Import an app");
        importBtn.setOnClickListener(v -> {
            try {
                picker.launch(new String[]{"*/*"});
            } catch (RuntimeException e) {
                Toast.makeText(this, "No file picker is available on this phone.", Toast.LENGTH_LONG).show();
            }
        });
        root.addView(importBtn, margins(0, 0, 0, dp(8)));

        root.addView(text("Pick a .html file, or a .zip if your app has separate CSS, "
                + "JavaScript or image files.", 12, INK3, false), margins(0, 0, 0, dp(18)));

        busy = new ProgressBar(this);
        busy.setVisibility(View.GONE);
        root.addView(busy, margins(0, 0, 0, dp(12)));

        listHolder = column();
        root.addView(listHolder);

        return scroll;
    }

    private void refresh() {
        listHolder.removeAllViews();
        List<AppStore.Entry> apps = AppStore.load(this);

        if (apps.isEmpty()) {
            LinearLayout empty = card();
            empty.addView(text("Nothing imported yet", 15, INK, true));
            empty.addView(text("Tap Import an app above and choose your HTML file. "
                    + "It takes a few seconds and the app never leaves this phone.",
                    13, INK2, false), margins(0, dp(4), 0, 0));
            listHolder.addView(empty);
            return;
        }

        for (AppStore.Entry e : apps) {
            listHolder.addView(rowFor(e), margins(0, 0, 0, dp(10)));
        }
    }

    private View rowFor(final AppStore.Entry e) {
        LinearLayout box = card();

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        ImageView icon = new ImageView(this);
        icon.setImageBitmap(IconFactory.forApp(this, e, dp(48)));
        GradientDrawable clip = new GradientDrawable();
        clip.setCornerRadius(dp(12));
        icon.setBackground(clip);
        icon.setClipToOutline(true);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(48), dp(48));
        ip.rightMargin = dp(12);
        head.addView(icon, ip);

        LinearLayout meta = column();
        meta.addView(text(e.name, 16, INK, true));
        meta.addView(text(sizeLabel(e.bytes) + "  ·  added " + dateLabel(e.created), 12, INK3, false));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        head.addView(meta, mp);

        box.addView(head);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(12), 0, 0);

        TextView open = filledButton("Open");
        open.setOnClickListener(v -> startActivity(Shortcuts.launchIntent(this, e)));
        actions.addView(open, weighted(1f, 0, 0, dp(8), 0));

        TextView pin = outlineButton("Add to home screen");
        pin.setOnClickListener(v -> {
            if (!Shortcuts.supported(this)) {
                Toast.makeText(this, "This launcher does not allow apps to add icons. "
                        + "You can still open it from here.", Toast.LENGTH_LONG).show();
                return;
            }
            if (!Shortcuts.pin(this, e)) {
                Toast.makeText(this, "The launcher refused the icon.", Toast.LENGTH_LONG).show();
            }
        });
        actions.addView(pin, weighted(1.4f, 0, 0, 0, 0));

        box.addView(actions);

        LinearLayout minor = new LinearLayout(this);
        minor.setOrientation(LinearLayout.HORIZONTAL);
        minor.setPadding(0, dp(8), 0, 0);

        TextView rename = linkButton("Rename", INK2);
        rename.setOnClickListener(v -> promptRename(e));
        minor.addView(rename, weighted(1f, 0, 0, dp(8), 0));

        TextView remove = linkButton("Delete", BRICK);
        remove.setOnClickListener(v -> promptDelete(e));
        minor.addView(remove, weighted(1f, 0, 0, 0, 0));

        box.addView(minor);
        return box;
    }

    /* ----------------------------------------------------------- actions -- */

    private void doImport(final Uri uri) {
        busy.setVisibility(View.VISIBLE);
        io.execute(() -> {
            try {
                final AppStore.Entry e = Importer.importFrom(ManagerActivity.this, uri);
                AppStore.add(ManagerActivity.this, e);
                ui.post(() -> {
                    busy.setVisibility(View.GONE);
                    refresh();
                    offerPin(e);
                });
            } catch (Importer.ImportException | IOException ex) {
                final String message = ex.getMessage() == null
                        ? "That file could not be imported." : ex.getMessage();
                ui.post(() -> {
                    busy.setVisibility(View.GONE);
                    new AlertDialog.Builder(ManagerActivity.this)
                            .setTitle("Import stopped")
                            .setMessage(message)
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        });
    }

    private void offerPin(final AppStore.Entry e) {
        if (!Shortcuts.supported(this)) {
            startActivity(Shortcuts.launchIntent(this, e));
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(e.name + " is ready")
                .setMessage("Put it on your home screen now?")
                .setPositiveButton("Add icon", (d, w) -> Shortcuts.pin(this, e))
                .setNegativeButton("Just open it", (d, w) -> startActivity(Shortcuts.launchIntent(this, e)))
                .setNeutralButton("Later", null)
                .show();
    }

    private void promptRename(final AppStore.Entry e) {
        final EditText field = new EditText(this);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        field.setText(e.name);
        field.setSelectAllOnFocus(true);
        int pad = dp(20);
        field.setPadding(pad, dp(12), pad, dp(12));

        new AlertDialog.Builder(this)
                .setTitle("Rename")
                .setView(field)
                .setPositiveButton("Save", (d, w) -> {
                    String name = field.getText().toString().trim();
                    if (name.isEmpty()) return;
                    e.name = name.length() > 40 ? name.substring(0, 40) : name;
                    try {
                        AppStore.update(this, e);
                        refresh();
                        Toast.makeText(this, "Renamed. Existing home screen icons keep their old name "
                                + "until you add them again.", Toast.LENGTH_LONG).show();
                    } catch (IOException ex) {
                        Toast.makeText(this, "Could not save the new name.", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void promptDelete(final AppStore.Entry e) {
        new AlertDialog.Builder(this)
                .setTitle("Delete " + e.name + "?")
                .setMessage("Its files and anything it saved are removed from this phone. "
                        + "The home screen icon stops working. This cannot be undone.")
                .setPositiveButton("Delete", (d, w) -> {
                    try {
                        AppStore.delete(this, e.id);
                        AssetServer.forget(e.id);
                        refresh();
                    } catch (IOException ex) {
                        Toast.makeText(this, "Could not remove it.", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Keep", null)
                .show();
    }

    /* ------------------------------------------------------------- views -- */

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return l;
    }

    private LinearLayout card() {
        LinearLayout l = column();
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), RULE);
        l.setBackground(bg);
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        return l;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLineSpacing(0f, 1.25f);
        return t;
    }

    private TextView filledButton(String label) {
        TextView t = text(label, 15, Color.WHITE, true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(BRAND);
        bg.setCornerRadius(dp(8));
        t.setBackground(bg);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(13), dp(16), dp(13));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView outlineButton(String label) {
        TextView t = text(label, 15, BRAND, true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.TRANSPARENT);
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), RULE);
        t.setBackground(bg);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(13), dp(12), dp(13));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private TextView linkButton(String label, int color) {
        TextView t = text(label, 13, color, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private LinearLayout.LayoutParams margins(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(l, t, r, b);
        return p;
    }

    private LinearLayout.LayoutParams weighted(float weight, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        p.setMargins(l, t, r, b);
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static String sizeLabel(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1048576) return String.format(Locale.US, "%.0f KB", bytes / 1024.0);
        return String.format(Locale.US, "%.1f MB", bytes / 1048576.0);
    }

    private static String dateLabel(long millis) {
        if (millis <= 0) return "recently";
        return DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(millis));
    }
}
