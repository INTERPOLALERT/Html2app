package com.web2app.container;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.ServiceWorkerClientCompat;
import androidx.webkit.ServiceWorkerControllerCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * One imported app, running in its own window.
 *
 * From the user's side this is their app: their icon launched it, their name is
 * in the recents switcher, there is no address bar and no container UI.
 */
public class AppActivity extends AppCompatActivity implements NativeBridge.Host {

    public static final String EXTRA_APP_ID = "app_id";
    private static final String CHANNEL_ID = "web2app_apps";

    private final Handler ui = new Handler(Looper.getMainLooper());

    private WebView web;
    private AppStore.Entry app;
    private WebViewAssetLoader loader;
    private NativeBridge bridge;

    // Pending work that had to wait for a permission dialog or a picker.
    private PermissionRequest pendingWebPermission;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private ValueCallback<Uri[]> pendingFileChooser;
    private int pendingBridgePick = 0;
    private int pendingNotificationRequest = 0;
    private String pendingNotificationTitle;
    private String pendingNotificationBody;

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),
                    result -> {
                        boolean allGranted = !result.isEmpty() && !result.containsValue(false);
                        deliverPermissionOutcome(allGranted);
                    });

    private final ActivityResultLauncher<Intent> chooserLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        ValueCallback<Uri[]> cb = pendingFileChooser;
                        pendingFileChooser = null;
                        if (cb == null) return;
                        cb.onReceiveValue(extractUris(result.getResultCode(), result.getData()));
                    });

    private final ActivityResultLauncher<String[]> bridgePickLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(),
                    uri -> {
                        int req = pendingBridgePick;
                        pendingBridgePick = 0;
                        if (req == 0) return;
                        resolve(req, uri == null ? null : readAsJson(uri));
                    });

    /* ------------------------------------------------------------------ */

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String id = getIntent() == null ? null : getIntent().getStringExtra(EXTRA_APP_ID);
        if (id == null && getIntent() != null && getIntent().getData() != null) {
            id = getIntent().getData().getLastPathSegment();
        }
        app = AppStore.find(this, id);
        if (app == null) {
            Toast.makeText(this, "That app is no longer installed.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, ManagerActivity.class));
            finish();
            return;
        }

        setTitle(app.name);
        applyStatusBar(IconFactory.parse(app.color));
        createNotificationChannel();

        try {
            loader = AssetServer.loaderFor(this, app);
        } catch (RuntimeException e) {
            // Only reachable if the app's folder was removed underneath us.
            Toast.makeText(this, "That app's files are missing. Import it again.",
                    Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, ManagerActivity.class));
            finish();
            return;
        }
        installServiceWorkerBridge();

        web = new WebView(this);
        web.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        web.setBackgroundColor(Color.WHITE);
        configure(web);
        setContentView(web);

        bridge = new NativeBridge(this, this, app);
        web.addJavascriptInterface(bridge, "NativeBridge");
        injectBridgeShim();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (web != null && web.canGoBack()) web.goBack();
                else finish();
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(app.startUrl());
        }
    }

    @SuppressWarnings("deprecation")
    private void configure(WebView v) {
        WebSettings s = v.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // Local files are reached through the https asset server, never
        // directly, so every file:// door stays shut.
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(v, false);

        v.setWebViewClient(new AppWebViewClient());
        v.setWebChromeClient(new AppChromeClient());
        v.setDownloadListener((url, agent, disposition, mime, size) -> handleDownload(url, disposition, mime));

        WebView.setWebContentsDebuggingEnabled(false);
    }

    private void injectBridgeShim() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                WebViewCompat.addDocumentStartJavaScript(
                        web, NativeBridge.shim(),
                        Collections.singleton("https://" + app.host()));
                return;
            } catch (RuntimeException ignored) {
                // Falls through to the page-load injection below.
            }
        }
        // Older WebViews: the shim is idempotent, so injecting on every page
        // event is safe and covers navigations within the app.
    }

    private void installServiceWorkerBridge() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_BASIC_USAGE)) return;
        try {
            ServiceWorkerControllerCompat.getInstance().setServiceWorkerClient(
                    new ServiceWorkerClientCompat() {
                        @Nullable
                        @Override
                        public WebResourceResponse shouldInterceptRequest(@NonNull WebResourceRequest request) {
                            return AssetServer.serve(getApplicationContext(), request.getUrl());
                        }
                    });
        } catch (RuntimeException ignored) {
            // Service workers are a bonus. Apps without one are unaffected.
        }
    }

    /* ---------------------------------------------------------- WebView -- */

    private final class AppWebViewClient extends WebViewClient {

        @Nullable
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return loader.shouldInterceptRequest(request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri url = request.getUrl();
            if (AssetServer.isLocal(url)) return false;

            // Anything that is not this app's own content leaves for the real
            // browser. That keeps the native bridge out of reach of any page we
            // did not import.
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, url)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (RuntimeException e) {
                toast("Nothing on this phone can open that link.");
            }
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                view.evaluateJavascript(NativeBridge.shim(), null);
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                view.evaluateJavascript(NativeBridge.shim(), null);
            }
        }
    }

    private final class AppChromeClient extends WebChromeClient {

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            ui.post(() -> {
                pendingWebPermission = request;
                List<String> needed = new ArrayList<>();
                for (String r : request.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                            && !granted(Manifest.permission.CAMERA)) {
                        needed.add(Manifest.permission.CAMERA);
                    } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                            && !granted(Manifest.permission.RECORD_AUDIO)) {
                        needed.add(Manifest.permission.RECORD_AUDIO);
                    }
                }
                if (needed.isEmpty()) {
                    deliverPermissionOutcome(true);
                } else {
                    permissionLauncher.launch(needed.toArray(new String[0]));
                }
            });
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest request) {
            ui.post(() -> {
                if (pendingWebPermission == request) pendingWebPermission = null;
            });
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            ui.post(() -> {
                pendingGeoOrigin = origin;
                pendingGeoCallback = callback;
                if (granted(Manifest.permission.ACCESS_FINE_LOCATION)
                        || granted(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    deliverPermissionOutcome(true);
                } else {
                    permissionLauncher.launch(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION});
                }
            });
        }

        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
            pendingFileChooser = callback;
            try {
                chooserLauncher.launch(params.createIntent());
                return true;
            } catch (RuntimeException e) {
                pendingFileChooser = null;
                toast("No app on this phone can pick that kind of file.");
                return false;
            }
        }
    }

    /* ------------------------------------------------------ permissions -- */

    private boolean granted(String permission) {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
    }

    /** Routes a permission answer to whichever request was waiting on it. */
    private void deliverPermissionOutcome(boolean allowed) {
        if (pendingWebPermission != null) {
            PermissionRequest req = pendingWebPermission;
            pendingWebPermission = null;
            if (allowed) req.grant(req.getResources());
            else req.deny();
            return;
        }
        if (pendingGeoCallback != null) {
            GeolocationPermissions.Callback cb = pendingGeoCallback;
            String origin = pendingGeoOrigin;
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
            cb.invoke(origin, allowed, false);
            return;
        }
        if (pendingNotificationRequest != 0) {
            int req = pendingNotificationRequest;
            String title = pendingNotificationTitle;
            String body = pendingNotificationBody;
            pendingNotificationRequest = 0;
            pendingNotificationTitle = null;
            pendingNotificationBody = null;
            if (allowed) postNotification(req, title, body);
            else resolve(req, "{\"ok\":false,\"reason\":\"denied\"}");
        }
    }

    /* -------------------------------------------------------- downloads -- */

    private void handleDownload(String url, String contentDisposition, String mime) {
        String name = guessName(url, contentDisposition, mime);
        if (url.startsWith("blob:")) {
            // A blob only exists inside the page, so the page has to hand it
            // back as a data URL before anything native can write it out.
            String js = "(function(){fetch(" + NativeBridge.jsString(url) + ")"
                    + ".then(function(r){return r.blob();})"
                    + ".then(function(b){var fr=new FileReader();"
                    + "fr.onload=function(){var p=window.NativeBridge.saveToDownloads("
                    + NativeBridge.jsString(name) + ",fr.result);"
                    + "window.NativeBridge.toast(p?('Saved to '+p):'Could not save that file');};"
                    + "fr.readAsDataURL(b);})"
                    + ".catch(function(){window.NativeBridge.toast('Could not read that file');});})()";
            web.evaluateJavascript(js, null);
            return;
        }
        if (url.startsWith("data:")) {
            String saved = bridge.saveToDownloads(name, url);
            toast(saved != null ? "Saved to " + saved : "Could not save that file");
            return;
        }
        if (AssetServer.isLocal(Uri.parse(url))) {
            String js = "(function(){fetch(" + NativeBridge.jsString(url) + ")"
                    + ".then(function(r){return r.blob();})"
                    + ".then(function(b){var fr=new FileReader();"
                    + "fr.onload=function(){var p=window.NativeBridge.saveToDownloads("
                    + NativeBridge.jsString(name) + ",fr.result);"
                    + "window.NativeBridge.toast(p?('Saved to '+p):'Could not save that file');};"
                    + "fr.readAsDataURL(b);});})()";
            web.evaluateJavascript(js, null);
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (RuntimeException e) {
            toast("Could not open that download.");
        }
    }

    private String guessName(String url, String disposition, String mime) {
        try {
            String n = android.webkit.URLUtil.guessFileName(url, disposition, mime);
            if (n != null && !n.isEmpty()) return n;
        } catch (RuntimeException ignored) {
            // Fall through to the generic name below.
        }
        return "download-" + System.currentTimeMillis();
    }

    /* ----------------------------------------------------- bridge hooks -- */

    @Override
    public void runOnUi(Runnable r) {
        ui.post(r);
    }

    @Override
    public void resolve(int requestId, String json) {
        ui.post(() -> {
            if (web == null) return;
            web.evaluateJavascript("window.__w2aResolve && window.__w2aResolve("
                    + requestId + "," + NativeBridge.jsString(json) + ")", null);
        });
    }

    @Override
    public void requestFilePick(int requestId, String mimeType) {
        ui.post(() -> {
            if (pendingBridgePick != 0) {
                resolve(requestId, null);
                return;
            }
            pendingBridgePick = requestId;
            try {
                bridgePickLauncher.launch(new String[]{mimeType});
            } catch (RuntimeException e) {
                pendingBridgePick = 0;
                resolve(requestId, null);
            }
        });
    }

    @Override
    public void requestNotification(int requestId, String title, String body) {
        ui.post(() -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                    && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
                pendingNotificationRequest = requestId;
                pendingNotificationTitle = title;
                pendingNotificationBody = body;
                permissionLauncher.launch(new String[]{Manifest.permission.POST_NOTIFICATIONS});
                return;
            }
            postNotification(requestId, title, body);
        });
    }

    private void postNotification(int requestId, String title, String body) {
        try {
            NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setColor(IconFactory.parse(app.color))
                    .setAutoCancel(true)
                    .setContentIntent(android.app.PendingIntent.getActivity(
                            this, app.id.hashCode(), Shortcuts.launchIntent(this, app),
                            android.app.PendingIntent.FLAG_UPDATE_CURRENT
                                    | android.app.PendingIntent.FLAG_IMMUTABLE))
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);

            NotificationManagerCompat.from(this)
                    .notify(app.id.hashCode() + requestId, b.build());
            resolve(requestId, "{\"ok\":true}");
        } catch (SecurityException | RuntimeException e) {
            resolve(requestId, "{\"ok\":false,\"reason\":\"failed\"}");
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "App notifications", NotificationManager.IMPORTANCE_DEFAULT);
        ch.setDescription("Notifications sent by your imported apps");
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(ch);
    }

    @Override
    public void setStatusBarColor(int color) {
        ui.post(() -> applyStatusBar(color));
    }

    private void applyStatusBar(int color) {
        getWindow().setStatusBarColor(color);
        View decor = getWindow().getDecorView();
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), decor);
        c.setAppearanceLightStatusBars(IconFactory.onColor(color) == 0xFF101010);
    }

    @Override
    public void setKeepAwake(boolean on) {
        ui.post(() -> {
            if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    @Override
    public void shareText(String text, String title) {
        ui.post(() -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            if (title != null) i.putExtra(Intent.EXTRA_SUBJECT, title);
            try {
                startActivity(Intent.createChooser(i, title == null ? "Share" : title));
            } catch (RuntimeException e) {
                toast("Nothing to share to.");
            }
        });
    }

    @Override
    public void toast(String message) {
        ui.post(() -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
    }

    @Override
    public void vibrate(long ms) {
        ui.post(() -> {
            try {
                Vibrator v;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    VibratorManager vm = getSystemService(VibratorManager.class);
                    v = vm == null ? null : vm.getDefaultVibrator();
                } else {
                    v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                }
                if (v == null || !v.hasVibrator()) return;
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            } catch (RuntimeException ignored) {
                // Vibration is never important enough to crash an app over.
            }
        });
    }

    @Override
    public void closeApp() {
        ui.post(this::finish);
    }

    /* ------------------------------------------------------------ misc -- */

    private Uri[] extractUris(int resultCode, @Nullable Intent data) {
        if (resultCode != RESULT_OK || data == null) return null;
        if (data.getClipData() != null) {
            android.content.ClipData clip = data.getClipData();
            Uri[] out = new Uri[clip.getItemCount()];
            for (int i = 0; i < clip.getItemCount(); i++) out[i] = clip.getItemAt(i).getUri();
            return out;
        }
        return data.getData() == null ? null : new Uri[]{data.getData()};
    }

    /** Reads a picked file into a JSON payload the page can use directly. */
    private String readAsJson(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return null;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[32 * 1024];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 32L * 1024 * 1024) {
                    return "{\"error\":\"That file is larger than 32 MB.\"}";
                }
                bos.write(buf, 0, n);
            }
            String mime = getContentResolver().getType(uri);
            if (mime == null) mime = "application/octet-stream";

            JSONObject o = new JSONObject();
            o.put("name", displayName(uri));
            o.put("type", mime);
            o.put("size", bos.size());
            o.put("dataUrl", "data:" + mime + ";base64,"
                    + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP));
            return o.toString();
        } catch (IOException | JSONException | SecurityException | OutOfMemoryError e) {
            return null;
        }
    }

    private String displayName(Uri uri) {
        try (android.database.Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) {
                    String n = c.getString(idx);
                    if (n != null) return n;
                }
            }
        } catch (RuntimeException ignored) {
            // Providers are not obliged to answer. A generic name is fine.
        }
        return "file";
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.setWebChromeClient(null);
            web.loadUrl("about:blank");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
