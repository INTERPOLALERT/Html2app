package com.web2app.container;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceResponse;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Serves each imported app's files over https from its own host name.
 *
 * The https scheme is the whole point. A WebView loading file:// is not a secure
 * context, which silently disables getUserMedia, geolocation, service workers
 * and crypto.subtle. Serving the very same local files over
 * https://&lt;id&gt;.web2app.local makes all of that work, and gives every app a
 * separate storage origin at the same time.
 */
public final class AssetServer {

    private static final Map<String, WebViewAssetLoader> LOADERS = new HashMap<>();

    private AssetServer() { }

    public static synchronized WebViewAssetLoader loaderFor(Context ctx, AppStore.Entry e) {
        WebViewAssetLoader cached = LOADERS.get(e.id);
        if (cached != null) return cached;

        File dir = AppStore.dirFor(ctx.getApplicationContext(), e.id);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(e.host())
                .setHttpAllowed(false)
                .addPathHandler("/", new WebViewAssetLoader.InternalStoragePathHandler(
                        ctx.getApplicationContext(), dir))
                .build();
        LOADERS.put(e.id, loader);
        return loader;
    }

    public static synchronized void forget(String appId) {
        LOADERS.remove(appId);
    }

    /**
     * Resolves a request by host name alone. Used by the service-worker
     * interceptor, which is process-wide and has no idea which app it belongs
     * to, and by any activity serving a second app at the same time.
     */
    public static WebResourceResponse serve(Context ctx, Uri url) {
        if (url == null) return null;
        AppStore.Entry e = AppStore.findByHost(ctx.getApplicationContext(), url.getHost());
        if (e == null) return null;
        try {
            return loaderFor(ctx, e).shouldInterceptRequest(url);
        } catch (RuntimeException ex) {
            return null;
        }
    }

    /** True for URLs belonging to any imported app. */
    public static boolean isLocal(Uri url) {
        return url != null
                && "https".equalsIgnoreCase(url.getScheme())
                && url.getHost() != null
                && url.getHost().endsWith(AppStore.HOST_SUFFIX);
    }
}
